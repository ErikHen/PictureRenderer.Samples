define("epi-cms/component/command/NewBlock", [
// dojo
    "dojo/_base/declare",
    "dojo/when",
    // epi
    "epi/shell/DestroyableByKey",
    "epi/dependency",

    "epi-cms/ApplicationSettings",
    // command
    "epi-cms/command/NewContent",

    // resource
    "epi/i18n!epi/cms/nls/episerver.cms.components.createblock"
],

function (
// dojo
    declare,
    when,
    // epi
    DestroyableByKey,
    dependency,

    ApplicationSettings,
    // command
    NewContentCommand,

    // resource
    resCreateBlock
) {

    return declare([NewContentCommand, DestroyableByKey], {
        // summary:
        //      New block command specially brewed for the SharedBlocksViewModel it will be disabled if the user is searching for content
        // tags:
        //      internal

        contentType: "episerver.core.blockdata",
        iconClass: "epi-iconCreateSharedBlock",
        label: resCreateBlock.command.label,
        resources: resCreateBlock,

        viewModel: null,

        _onModelChange: function () {

            // Listen to changes to the isSearching property on the view model and re-execute the onModelChange method to trigger
            // the canExecute methods to be re-evaluated
            if (this.viewModel && this.viewModel.watch) {
                this.destroyByKey("isSearchingWatch");
                this.ownByKey("isSearchingWatch", this.viewModel.watch("isSearching", this._onModelChange.bind(this)));
            }

            this.inherited(arguments);
        },

        _canExecute: function () {
            // summary:
            //      Determines if the command can be executed and taking isSearching into calculations
            // tags:
            //      protected overridden

            var canExecute = this.inherited(arguments);

            var self = this;
            function isSearching() {
                if (!self.viewModel || !self.viewModel.get) {
                    return false;
                }
                return self.viewModel.get("isSearching");
            }

            // If the user is searching for content can execute should be false
            return canExecute && !isSearching();
        },

        _checkAvailability: function () {
            if (ApplicationSettings.limitUI) {
                if (!this.model.capabilities.isContentFolder) {
                    return false;
                }
            }

            return this.inherited(arguments);
        }
    });
});
