﻿define("epi-cms/contentediting/editors/EnumFlagsEditor", [
    "dojo/_base/declare",
    "epi-cms/contentediting/editors/CheckBoxListEditor"
], function (declare, CheckBoxListEditor) {

    return declare([CheckBoxListEditor], {
        // tags:
        //      internal

        _calculateValue: function () {
            var bitSum = this._checkboxes.filter(function (checkbox) {
                return checkbox.checked;
            }).reduce(function (acc, checkbox) {
                return acc + checkbox.value;
            }, 0);

            this._set("value", bitSum);
        },

        _setValueAttr: function (value) {
            this._set("value", value);

            this._checkboxes.forEach(function (checkbox) {
                checkbox.set("checked", value & checkbox.value);
            });
        }
    });
});
